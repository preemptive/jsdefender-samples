# PreEmptive Protection JSDefender

## Overview

JSDefender is a tool that protects JavaScript files by transforming them, using several different code transformation and injection techniques.

To learn about the usage and options head over to the [online docs](https://www.preemptive.com/jsdefender/2.3/userguide/en/index.html).
