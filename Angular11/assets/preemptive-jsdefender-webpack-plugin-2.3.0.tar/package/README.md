# PreEmptive Protection JSDefender Webpack Plugin

## Overview

A webpack plugin which runs JSDefender on the webpack chunks using the compiler's `emit` hook.

To learn about the usage and options head over to the [online docs](https://www.preemptive.com/jsdefender/2.3/userguide/en/index.html).
